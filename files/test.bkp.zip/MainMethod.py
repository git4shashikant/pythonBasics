import HelloWorld

print(50 * "-")


def main():
    print("Start main()")
    test()


def test():
    print("test()")


if __name__ == "__main__":
    main()

print("intermediate code line")
print("Value in built variable name is:  ", __name__)
print("End main()")
print(50 * "-")
