import urllib.request

web_url = urllib.request.urlopen("https://google.com")
print(web_url.getCode())
print(web_url.read())
