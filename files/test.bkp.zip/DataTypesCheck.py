str_list = "Welcome to Guru99"
age = 50
pi = 3.14
c_num = 3j+10
my_list = ["A", "B", "C", "D"]
my_tuple = ("A", "B", "C", "D")
my_dict = {"A": "a", "B": "b", "C": "c", "D": "d"}
my_set = {'A', 'B', 'C', 'D'}

print("The type is : ", type(str_list))
print("The type is : ", type(age))
print("The type is : ", type(pi))
print("The type is : ", type(c_num))
print("The type is : ", type(my_list))
print("The type is : ", type(my_tuple))
print("The type is : ", type(my_dict))
print("The type is : ", type(my_set))
print(isinstance(my_dict, dict))
print(isinstance(my_list, list))
print(isinstance(my_set, set))
print(isinstance(my_tuple, tuple))
