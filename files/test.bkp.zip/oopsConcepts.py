class oopsConcepts:
    name = ""

    def __init__(self, name):
        self.name = name

    def methodTest1(self):
        print("method-1 of " + self.name)

    def methodTest2(self, string):
        print("method-2 of " + self.name + ", " + string)


class childClass(oopsConcepts):
    def __init__(self, name):
        self.name = name

    # method can be overloaded
    def methodTest2(self, string1, string2):
        print("method-2 of " + self.name + ", " + string1 + ", " + string2)

    def methodTest3(self):
        print("method-3 of " + self.name)


def main():
    c = oopsConcepts("oopsConcepts")
    c.methodTest1()
    c.methodTest2(" complete.")

    d = childClass("chileClass")
    d.methodTest2("from child class", " second parameter")
    d.methodTest3()


if __name__ == "__main__":
    main()





